﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Configuration;
using System.Data.SqlClient;
using System.Data.Sql;
using Excel = Microsoft.Office.Interop.Excel;
using Word= Microsoft.Office.Interop.Word;
using System.Data.OleDb;

namespace Word_To_Excel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            ReadMsWord();
        }

        public void ReadMsWord()
        {  
            // variable to store file path
            string filePath=null;
            // open dialog box to select file
            OpenFileDialog file= new OpenFileDialog();
            // dilog box title name
            file.Title="Word File";
            // set initial directory of computer system
            file.InitialDirectory= "c:\\";
            // set restore directory
            file.RestoreDirectory= true;
 
            // execute if block when dialog result box click ok button
            if (file.ShowDialog() ==DialogResult.OK)
            {
                // store selected file path
                filePath=file.FileName.ToString();          
            }
 
            try
            { 
                // create word application
                Microsoft.Office.Interop.Word.Application word=new Microsoft.Office.Interop.Word.Application();
                // create object of missing value
                object miss= System.Reflection.Missing.Value;
                // create object of selected file path
                object path=filePath;
                // set file path mode
                object readOnly= false;
                // open document                
                Microsoft.Office.Interop.Word.Document docs=word.Documents.Open(ref path, ref miss, ref readOnly, ref miss, ref miss, ref miss, ref miss, ref miss,ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss, ref miss);
              // select whole data from active window document
                docs.ActiveWindow.Selection.WholeStory();
                // handover the data to cllipboard
                docs.ActiveWindow.Selection.Copy();
                // clipboard create reference of idataobject interface which transfer the data
                IDataObject data= Clipboard.GetDataObject();
                //set data into richtextbox control in text format
                richTextBox2.Text=data.GetData(DataFormats.Text).ToString();
                richTextBox2.Text = richTextBox2.Text.Trim();
                // read bitmap image from clipboard with help of iddataobject interface
                //Image img= (Image)data.GetData(DataFormats.Bitmap);
                // close the document
                //docs.Close(refmiss, refmiss, refmiss);
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            import();
        }
        protected void import() {
            String question="", opt1="", opt2="", opt3="", opt4="", correct_answer="", comment="";
            DataTable _dt = new DataTable();
            
            _dt.Columns.Add("question");
            _dt.Columns.Add("opt1");
            _dt.Columns.Add("opt2");
            _dt.Columns.Add("opt3");
            _dt.Columns.Add("opt4");
            _dt.Columns.Add("correct_answer");
            _dt.Columns.Add("Comment");
            _dt.Columns.Add("questionno");
            //_dt.Columns.Add("comment");
            int que = 0,opta=0,optb=0,optc=0,optd=0;
            int count = 1;    
            for (int i = 0; i < richTextBox2.Lines.Length; i++)
            {
                opt1 = "";
                opt2 = "";
                opt3 = "";
                opt4 = "";
                String line=richTextBox2.Lines[i].Trim();
                //question = "testing";
                
                if (i == 0) {
                ab:
                    line = richTextBox2.Lines[i].Trim();
                    for (int j = 0; j < line.Length; j++)
                    {
                        question += line[j] + "";
                    }
                    if ((i + 1) != richTextBox2.Lines.Length)
                    {
                        line = richTextBox2.Lines[i + 1].Trim();
                        if (line.StartsWith("(a)"))
                        {
                            i++;
                            count++;
                        }
                        else
                        {
                            i = i + 1;
                            goto ab;
                            
                        }
                    }
                }
                if (i != richTextBox2.Lines.Length)
                {
                    line = richTextBox2.Lines[i].Trim();
                } 
                if (line.Contains("(a)"))
                {
                    int d = line.IndexOf("(b)");
                    if (d > 0)
                    {
                        for (int j = 0; j < d; j++)
                        {
                            opt1 += line[j] + "";
                        }
                    }
                    else
                    {
                        for (int j = 0; j < line.Length; j++)
                        {
                            opt1 += line[j] + "";
                        }
                        i++;
                    }
                }

                if (i != richTextBox2.Lines.Length)
                {
                    line = richTextBox2.Lines[i].Trim();
                } 
                if (line.Contains("(b)"))
                {
                    int d = line.IndexOf("(b)");
                    if (d > 0)
                    {
                        for (int j = d; j <line.Length; j++)
                        {
                            opt2 += line[j] + "";
                        }
                        i++;
                    }
                    else
                    {
                        for (int j = 0; j < line.Length; j++)
                        {
                            opt2 += line[j] + "";
                        }
                        i++;
                    }
                }

                if (i != richTextBox2.Lines.Length)
                {
                    line = richTextBox2.Lines[i].Trim();
                } 
                if (line.Contains("(c)"))
                {
                    int d = line.IndexOf("(d)");
                    if (d > 0)
                    {
                        for (int j = 0; j < d; j++)
                        {
                            opt3 += line[j] + "";
                        }
                    }
                    else
                    {
                        for (int j = 0; j < line.Length; j++)
                        {
                            opt3 += line[j] + "";
                        }
                        i++;
                    }
                }

                if (i != richTextBox2.Lines.Length)
                {
                    line = richTextBox2.Lines[i].Trim();
                } 
                if (line.Contains("(d)"))
                {
                    int d = line.IndexOf("(d)");
                    if (d > 0)
                    {
                        for (int j = d; j < line.Length; j++)
                        {
                            opt4 += line[j] + "";
                        }
                        i++;
                    }
                    else
                    {
                        for (int j = 0; j < line.Length; j++)
                        {
                            opt4 += line[j] + "";
                        }
                        i++;
                    }
                }
                if (i != richTextBox2.Lines.Length)
                {
                    line = richTextBox2.Lines[i].Trim();
                }
                if (line.StartsWith(count+".")) {
                    DataRow dr = _dt.NewRow();
                    int d = (count).ToString().Length+1;
                    dr[0] = question.Substring(d,question.Length-d);
                    dr[1] = opt1.Substring(3,opt1.Length-3);
                    dr[2] = opt2.Substring(3, opt2.Length - 3);
                    dr[3] = opt3.Substring(3, opt3.Length - 3);
                    dr[4] = opt4.Substring(3, opt4.Length - 3);
                    dr[5] = "";
                    dr[6] = "";
                    dr[7] = count-1;
                    _dt.Rows.Add(dr);
                    question = "";
                ab:
                    line = richTextBox2.Lines[i].Trim();
                    for (int j = 0; j < line.Length; j++)
                    {
                        question += line[j] + "";
                    }
                    if ((i + 1) != richTextBox2.Lines.Length)
                    {
                        line = richTextBox2.Lines[i + 1].Trim();
                        if (line.StartsWith("(a)"))
                        {
                            count++;
                        }
                        else
                        {
                            i = i + 1;
                            goto ab;
                        }
                    }
                }

                
            }


            //Setting Correct Answer Value
           int question_count=0;
           string correct_ans = " ";
           int ctr = 0;

           for (int i = 0; i < richTextBox1.Lines.Length; i++) {

                    String line = richTextBox1.Lines[i].ToString().Trim();
                    line=line.Replace('\t',' ');
                    String[] atr=line.Split(' ');
                    
                    for (int j = 0; j < atr.Length-1; j++)
                    {
                        if (ctr == _dt.Rows.Count)
                        {
                            break;
                        }
                     _dt.Rows[ctr][5] = atr[++j].Trim().ToUpper();
                     ctr++;
                    }
           }

           count = 1;
           string comment1 = "";
           DataTable _dt1 = new DataTable();
           _dt1.Columns.Add("Comment");
           for (int l = 0; l < _dt.Rows.Count;l++ )
           {
               string questnno =_dt.Rows[l]["questionno"].ToString();
               for (int m = 0; m < richTextBox3.Lines.Length; m++) {
                   int d = questnno.Length;
                   if (richTextBox3.Lines[m].StartsWith(questnno+".")) {
                       _dt.Rows[l][6] += richTextBox3.Lines[m];
                   }
               }
           }

           for (int l = 0; l < _dt.Rows.Count; l++)
           {
               _dt.Rows[l][6] = _dt.Rows[l][6].ToString().Trim();
               int d = _dt.Rows[l][6].ToString().Length;
               if (d > 3)
               {
                   _dt.Rows[l][6] = _dt.Rows[l][6].ToString().Substring(3, d - 3);
               }
               _dt.Rows[l][6] = _dt.Rows[l][6].ToString().Trim();
               d = _dt.Rows[l][6].ToString().Length;
               if (d > 3)
               {
                   _dt.Rows[l][6] = _dt.Rows[l][6].ToString().Substring(3, d - 3);
               }
           }

           dataGridView1.DataSource = _dt;
           ExportDTToExcel(_dt, @"D:book1.xls");  
            //ExportDTToExcel(_dt,"test");
        }



        
        private void button3_Click(object sender, EventArgs e)
        {
         }



        public static void ExportDTToExcel(System.Data.DataTable dt, string FileName)
        {

            Microsoft.Office.Interop.Excel.Application app = new Microsoft.Office.Interop.Excel.Application();
            app.Visible = false;

            Excel.Workbook wb = app.Workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);

            Excel.Worksheet ws = (Excel.Worksheet)wb.ActiveSheet;

            // Headers. 

            for (int i = 1; i < dt.Columns.Count; i++)
            {
                ws.Cells[1, i] = dt.Columns[i-1].ColumnName;
            }

            // Content. 
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                for (int j = 1; j < dt.Columns.Count; j++)
                {

                    ws.Cells[i + 2, j] = dt.Rows[i][j-1].ToString();

                }

            }

            // Lots of options here. See the documentation. 

            wb.SaveAs(FileName);


            wb.Close();

            app.Quit();

        }

    }


}
